package WINBUL;

public class Codigo {
	public String intentar (String numazar, String intento) {
		System.out.print("\n"+"inicia");
		String respuesta = "";
		int numazar1 = Integer.parseInt(numazar);
		int intento1 = Integer.parseInt(intento);

		int aleatorio = (int) ((Math.random() * 100)+1); // N�mero aleatorio de 1 a 100.
		System.out.print("\n"+aleatorio);
		 
		 for (int i=0; i<=intento1; i++) { 

			    // Primero se eval�a si se ha acertado.
			    
			    if (numazar1 == aleatorio) {  
			      respuesta=("�Has acertado!"); 
			      break; } 
			    
			    else if (numazar1 > aleatorio) 
			      respuesta=("El n�mero secreto es MENOR que " + numazar1);
			    else if (numazar1 < aleatorio)
			      respuesta=("El n�mero secreto es MAYOR que " + numazar1);
			    
			    else if (i == intento1) { 
				      respuesta=("Lo siento: �has perdido!. El n�mero era el: " + aleatorio); 
				      break; } 

		}
		return respuesta;
	}	 
}
