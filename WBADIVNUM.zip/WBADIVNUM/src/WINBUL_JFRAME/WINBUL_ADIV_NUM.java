package WINBUL_JFRAME;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import WINBUL.Codigo;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class WINBUL_ADIV_NUM extends JFrame {

	private JPanel contentPane;
	private Codigo WINBUL;
	private JTextField textField_numintentos;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JTextField textField_numazar;
	private JButton btnSalir;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WINBUL_ADIV_NUM frame = new WINBUL_ADIV_NUM();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WINBUL_ADIV_NUM() {
		setForeground(Color.BLACK);
		setTitle("                                                            Juego de adivinar");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 553, 340);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField_numintentos = new JTextField();
		textField_numintentos.setBackground(Color.ORANGE);
		textField_numintentos.setBounds(215, 39, 37, 18);
		contentPane.add(textField_numintentos);
		textField_numintentos.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Ingrese el n�mero de intentos:");
		lblNewLabel.setBounds(26, 41, 179, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Adivine el n\u00FAmero al azar");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(62, 11, 432, 14);
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("Ingresa el n\u00FAmero entre 1 y 100");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(46, 84, 448, 14);
		contentPane.add(lblNewLabel_2);
		
		textField_numazar = new JTextField();
		textField_numazar.setBackground(Color.ORANGE);
		textField_numazar.setBounds(215, 121, 86, 20);
		contentPane.add(textField_numazar);
		textField_numazar.setColumns(10);
		
		JLabel Label_respuesta = new JLabel("Respuesta");
		Label_respuesta.setHorizontalAlignment(SwingConstants.CENTER);
		Label_respuesta.setBounds(26, 175, 468, 14);
		contentPane.add(Label_respuesta);
		
		JButton btnNewButton_pulsador = new JButton("Intentar");
		btnNewButton_pulsador.setBackground(Color.CYAN);
		btnNewButton_pulsador.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Codigo xx = new Codigo();
				Label_respuesta.setText( xx.intentar( textField_numazar.getText(), textField_numintentos.getText()));
			}
		});
		btnNewButton_pulsador.setBounds(215, 214, 89, 23);
		contentPane.add(btnNewButton_pulsador);
		
		btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnSalir.setBackground(Color.RED);
		btnSalir.setBounds(215, 248, 89, 23);
		contentPane.add(btnSalir);
	}
}
