import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JFTriqui implements ActionListener{

	private JFrame frame;
	JButton btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9;
	JLabel resultado;
	int turno = 0;
	boolean jugar = true;
	private JButton btnReiniciar;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFTriqui window = new JFTriqui();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JFTriqui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 392, 362);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(4, 3, 0, 0));
		
		btn1 = new JButton(" - ");
		frame.getContentPane().add(btn1);
		btn1.addActionListener( this );
		
		btn2 = new JButton(" - ");
		frame.getContentPane().add(btn2);
		btn2.addActionListener( this );
		
		btn3 = new JButton(" - ");
		frame.getContentPane().add(btn3);
		btn3.addActionListener( this );
		
		btn4 = new JButton(" - ");
		frame.getContentPane().add(btn4);
		btn4.addActionListener( this );
		
		btn5 = new JButton(" - ");
		frame.getContentPane().add(btn5);
		btn5.addActionListener( this );
		
		btn6 = new JButton(" - ");
		frame.getContentPane().add(btn6);
		btn6.addActionListener( this );
		
		btn7 = new JButton(" - ");
		frame.getContentPane().add(btn7);
		btn7.addActionListener( this );
		
		btn8 = new JButton(" - ");
		frame.getContentPane().add(btn8);
		btn8.addActionListener( this );
		
		btn9 = new JButton(" - ");
		frame.getContentPane().add(btn9);
		btn9.addActionListener( this );
		
		resultado = new JLabel("New label");
		resultado.setBounds(46, 248, 297, 32);
		frame.getContentPane().add(resultado);
		btn9.addActionListener( this );
		
		btnReiniciar = new JButton("Reiniciar");
		btnReiniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reiniciar();
			}
		});
		btnReiniciar.setBounds(34, 293, 97, 25);
		frame.getContentPane().add(btnReiniciar);
	}
	
	public void actionPerformed( ActionEvent e ){
		turno++;
		String letra = "";
		letra = "O";
		if( turno%2 == 0 ) 
			letra = "X";
		
		System.out.println("Pulse boton " + e.getID() );
		if( e.getSource() == btn1 ){
			btn1.setText( letra );
			btn1.setEnabled( false );
		}
		if( e.getSource() == btn2 ){
			btn2.setText( letra );
			btn2.setEnabled( false );
		}
		if( e.getSource() == btn3 ){
			btn3.setText( letra );
			btn3.setEnabled( false );			
		}
		if( e.getSource() == btn4 ){
			btn4.setText( letra );
			btn4.setEnabled( false );
		}
		if( e.getSource() == btn5 ){
			btn5.setText( letra );
			btn5.setEnabled( false );
		}
		if( e.getSource() == btn6 ){
			btn6.setText( letra );
			btn6.setEnabled( false );
		}
		if( e.getSource() == btn7 ){
			btn7.setText( letra );
			btn7.setEnabled( false );
		}
		if( e.getSource() == btn8 ){
			btn8.setText( letra );
			btn8.setEnabled( false );
		}
		if( e.getSource() == btn9 ){
			btn9.setText( letra );
			btn9.setEnabled( false );
		}
		
		boolean triki = false;
		if( letra.equals( btn1.getText() ) && letra.equals( btn2.getText() ) && letra.equals( btn3.getText() ) )
			triki = true;
		if( letra.equals( btn4.getText() ) && letra.equals( btn5.getText() ) && letra.equals( btn6.getText() ) )
			triki = true;
		if( letra.equals( btn7.getText() ) && letra.equals( btn8.getText() ) && letra.equals( btn9.getText() ) )
			triki = true;
		if( letra.equals( btn1.getText() ) && letra.equals( btn4.getText() ) && letra.equals( btn7.getText() ) )
			triki = true;
		if( letra.equals( btn2.getText() ) && letra.equals( btn5.getText() ) && letra.equals( btn8.getText() ) )
			triki = true;
		if( letra.equals( btn3.getText() ) && letra.equals( btn6.getText() ) && letra.equals( btn9.getText() ) )
			triki = true;
		if( letra.equals( btn1.getText() ) && letra.equals( btn5.getText() ) && letra.equals( btn9.getText() ) )
			triki = true;
		if( letra.equals( btn3.getText() ) && letra.equals( btn5.getText() ) && letra.equals( btn7.getText() ) )
			triki = true;
		
		if( triki){
			resultado.setText("Triki de la " + letra);
			jugar = false;
		}
		else if( turno == 9 ){
			resultado.setText("Empate");
			jugar = false;			
		}
	}
	public void reiniciar(){
		btn1.setText(" - ");
		btn2.setText(" - ");
		btn3.setText(" - ");
		btn4.setText(" - ");
		btn5.setText(" - ");
		btn6.setText(" - ");
		btn7.setText(" - ");
		btn8.setText(" - ");
		btn9.setText(" - ");
		btn1.setEnabled(true);
		btn2.setEnabled(true);
		btn3.setEnabled(true);
		btn4.setEnabled(true);
		btn5.setEnabled(true);
		btn6.setEnabled(true);
		btn7.setEnabled(true);
		btn8.setEnabled(true);
		btn9.setEnabled(true);
		jugar = true;
		turno = 0;
		resultado.setText("");
	}
}
