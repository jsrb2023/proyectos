
import java.sql.*;

public class TestConnection {
  public static String bd       = "empresa";
  public static String login    = "root";
  public static String password = "";
  public static String url      = "jdbc:mysql://localhost/"+bd;
  
  public static void main(String[] args){ // throws SQLException {
	     conectar();
  }
  
  public static void conectar() {
    Connection conn = null;
    try {
      Class.forName("org.gjt.mm.mysql.Driver");
      conn = DriverManager.getConnection( url, login, password );
      if( conn != null) {
        System.out.println("Conexion a base de datos "+url+" ... Ok");
        //conn.close();
      }
    }
    catch( SQLException ex ) {
      System.out.println("Hubo un problema al intentar conectarse con la base de datos "+url);
    }
    catch( ClassNotFoundException ex ) {
      System.out.println( ex );
    }
    
    try {
            Statement st = conn.createStatement();
            st.executeUpdate("INSERT INTO departamentos VALUES ('40','VALLE' )");
            ResultSet rs = null;
            rs = st.executeQuery("SELECT * FROM departamentos ");
            while ( rs.next() ) {
                String depcod = rs.getString("depcod");
                String depnom = rs.getString("depnom");
                System.out.println(depcod+ " " + depnom );
            }
            st.executeUpdate("DELETE FROM departamentos");
            //st.executeUpdate("delete from departamentos where depcod = '40' " );
            conn.close();
    } catch (Exception e) {
         System.err.println("Tuvo una exception! ");
          System.err.println(e.getMessage());
    }    
  }
}
