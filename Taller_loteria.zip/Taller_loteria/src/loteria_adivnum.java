import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class loteria_adivnum extends JFrame {

	private JPanel contentPane;
	private JTextField textcifra1;
	private JTextField textcifra2;
	private JTextField textcifra3;
	private JTextField textcifra4;
	private JTextField textnums1;
	private JTextField textnums2;
	private JTextField textnums3;
	private JTextArea textarea_resultado;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loteria_adivnum frame = new loteria_adivnum();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});	       
	}

	/**
	 * Create the frame.
	 */
	public loteria_adivnum() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 479);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textcifra1 = new JTextField();
		textcifra1.setHorizontalAlignment(SwingConstants.CENTER);
		textcifra1.setEditable(false);
		textcifra1.setBounds(10, 46, 51, 36);
		contentPane.add(textcifra1);
		textcifra1.setColumns(10);
		
		textcifra2 = new JTextField();
		textcifra2.setHorizontalAlignment(SwingConstants.CENTER);
		textcifra2.setEditable(false);
		textcifra2.setBounds(113, 46, 66, 36);
		contentPane.add(textcifra2);
		textcifra2.setColumns(10);
		
		textcifra3 = new JTextField();
		textcifra3.setHorizontalAlignment(SwingConstants.CENTER);
		textcifra3.setEditable(false);
		textcifra3.setBounds(230, 46, 66, 36);
		contentPane.add(textcifra3);
		textcifra3.setColumns(10);
		
		textcifra4 = new JTextField();
		textcifra4.setHorizontalAlignment(SwingConstants.CENTER);
		textcifra4.setEditable(false);
		textcifra4.setBounds(365, 46, 59, 36);
		contentPane.add(textcifra4);
		textcifra4.setColumns(10);
		
		textnums1 = new JTextField();
		textnums1.setHorizontalAlignment(SwingConstants.CENTER);
		textnums1.setBounds(93, 145, 86, 20);
		contentPane.add(textnums1);
		textnums1.setColumns(10);
		
		textnums2 = new JTextField();
		textnums2.setHorizontalAlignment(SwingConstants.CENTER);
		textnums2.setBounds(93, 197, 86, 20);
		contentPane.add(textnums2);
		textnums2.setColumns(10);
		
		textnums3 = new JTextField();
		textnums3.setHorizontalAlignment(SwingConstants.CENTER);
		textnums3.setBounds(93, 250, 86, 20);
		contentPane.add(textnums3);
		textnums3.setColumns(10);
		
		JButton btnjugar = new JButton("JUGAR");
		btnjugar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jugar();
			}
		});
		btnjugar.setBounds(288, 196, 89, 23);
		contentPane.add(btnjugar);
		
		textarea_resultado = new JTextArea();
		textarea_resultado.setBounds(66, 307, 295, 107);
		contentPane.add(textarea_resultado);
		
	}
	
	public void jugar(){
		
		//RANDOM
		int numero1 = (int) ((Math.random() * 9)+1);
		String numero1s= String.valueOf(numero1);
		textcifra1.setText(numero1s);
		System.out.println(numero1);
		
		int numero2 = (int) ((Math.random() * 9)+1);
		String numero2s= String.valueOf(numero2);
		textcifra2.setText(numero2s);
		System.out.println(numero2);
		
		int numero3 = (int) ((Math.random() * 9)+1);
		String numero3s= String.valueOf(numero3);
		textcifra3.setText(numero3s);
		System.out.println(numero3);
		
		int numero4 = (int) ((Math.random() * 9)+1);
		String numero4s= String.valueOf(numero4);
		textcifra4.setText(numero4s);
		System.out.println(numero4);
		
		try {
			
			String nums1 = textnums1.getText();
			String nums2 = textnums2.getText();
			String nums3 = textnums3.getText();
			
			String nums1_1s = nums1.substring (0, 1);
			int nums1_1int = Integer.parseInt(nums1_1s);
			System.out.println(nums1_1int);
			
			String nums1_2s = nums1.substring (1, 2);
			int nums1_2int = Integer.parseInt(nums1_2s);
			System.out.println(nums1_2int);
			
			String nums1_3s = nums1.substring (2, 3);
			int nums1_3int = Integer.parseInt(nums1_3s);
			System.out.println(nums1_3int);
			
			String nums1_4s = nums1.substring (3, 4);
			int nums1_4int = Integer.parseInt(nums1_4s);
			System.out.println(nums1_4int);
			
			
			String nums2_1s = nums2.substring (0, 1);
			int nums2_1int = Integer.parseInt(nums2_1s);
			System.out.println(nums2_1int);
			
			String nums2_2s = nums2.substring (1, 2);
			int nums2_2int = Integer.parseInt(nums2_2s);
			System.out.println(nums2_2int);
			
			String nums2_3s = nums2.substring (2, 3);
			int nums2_3int = Integer.parseInt(nums2_3s);
			System.out.println(nums2_3int);
			
			String nums2_4s = nums2.substring (3, 4);
			int nums2_4int = Integer.parseInt(nums2_4s);
			System.out.println(nums2_4int);
			
			
			String nums3_1s = nums3.substring (0, 1);
			int nums3_1int = Integer.parseInt(nums3_1s);
			System.out.println(nums3_1int);
			
			String nums3_2s = nums3.substring (1, 2);
			int nums3_2int = Integer.parseInt(nums3_2s);
			System.out.println(nums3_2int);
			
			String nums3_3s = nums3.substring (2, 3);
			int nums3_3int = Integer.parseInt(nums3_3s);
			System.out.println(nums3_3int);
			
			String nums3_4s = nums3.substring (3, 4);
			int nums3_4int = Integer.parseInt(nums3_4s);
			System.out.println(nums3_4int);
			
			
			//VALIDACIONES

			if (nums1_1int == numero1 && nums1_2int == numero2 && nums1_3int == numero3) {  
				textarea_resultado.setText("Acertate las 3 primeras");
			} 
			    
			    else {
			    	textarea_resultado.setText("No acertaste las 3 primeras");
			    }
			if (nums1_2int == numero2 && nums1_3int == numero3 && nums1_4int == numero4) {  
				textarea_resultado.setText("Acertaste las 3 ultimas");
			} 
			    
			    else {
			    	textarea_resultado.setText("No acertaste las 3 ultimas");
			    }
			if (nums1_1int == numero1 && nums1_2int == numero2) {  
				textarea_resultado.setText("Acertaste las 2 primeras");
			} 
			    
			    else {
			    	textarea_resultado.setText("No acertaste las 2 primeras");
			    }
			if (nums1_3int == numero3 && nums1_4int == numero4) {  
				textarea_resultado.setText("Acertaste las 2 ultimas");
			} 
			    
			    else {
			    	textarea_resultado.setText("No acertaste las 2 ultimas");
			    }
			if (nums1_4int == numero4) {  
				textarea_resultado.setText("Acertaste la ultima cifra");
			} 
			    
			    else {
			    	textarea_resultado.setText("No acertaste la ultima cifra");
			    }
			
		}catch( Exception e ){
			textarea_resultado.setText("Ingrese datos validos.");
		}
		
	}
}
