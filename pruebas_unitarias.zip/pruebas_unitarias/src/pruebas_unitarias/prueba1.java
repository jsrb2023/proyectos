package pruebas_unitarias;

public class prueba1 {

	public int sumar (int a, int b) {
		return a+b;
	}
	
	public int restar (int a, int b) {
		return a-b;
	}
	
	public int multiplicar (int a, int b) {
		return a*b;
	}
	
	public int dividir (int a, int b) {
		return a/b;
	}
	
	public static void main(String[] args) {
		
	}
}
