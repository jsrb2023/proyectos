package pruebas_unitarias;
import junit.framework.TestCase;

public class TestPrueba1 extends TestCase{
	
	private prueba1 prueba1;
	
	public void escenario() {
		prueba1=new prueba1();
	}
	
	public void testsumar () {
		escenario();
		assertTrue(prueba1.sumar(2, 2)== (2*2));
	}
	public void testrestar () {
		escenario();
		assertEquals(3, prueba1.restar(5, 2));
	}
	
	public void testmultiplicar () {
		escenario();
		assertTrue(prueba1.multiplicar(2,2)==(2*2));
	}
	
	public void testdividir () {
		escenario();
		assertTrue(prueba1.dividir(2,2)==(2/2));;
	}
}
