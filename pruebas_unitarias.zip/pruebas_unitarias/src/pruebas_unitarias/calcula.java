package pruebas_unitarias;

public class calcula {
	
	public static void main( String args[]) {
		prueba1 x = new prueba1();
		System.out.println("Suma " + x.sumar(3, 2));
		
	}
}
